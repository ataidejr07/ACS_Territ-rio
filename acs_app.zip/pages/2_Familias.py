import streamlit as st

st.title("Página: 2 Familias")
st.write("Conteúdo de 2 Familias aqui.")