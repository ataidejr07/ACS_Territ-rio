import streamlit as st

st.title("Página: 6 Nascimentos Obitos")
st.write("Conteúdo de 6 Nascimentos Obitos aqui.")