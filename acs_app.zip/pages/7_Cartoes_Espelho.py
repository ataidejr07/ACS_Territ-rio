import streamlit as st

st.title("Página: 7 Cartoes Espelho")
st.write("Conteúdo de 7 Cartoes Espelho aqui.")