import streamlit as st

st.title("Página: 1 Domicilios")
st.write("Conteúdo de 1 Domicilios aqui.")