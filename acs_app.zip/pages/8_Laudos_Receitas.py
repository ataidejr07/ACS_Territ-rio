import streamlit as st

st.title("Página: 8 Laudos Receitas")
st.write("Conteúdo de 8 Laudos Receitas aqui.")