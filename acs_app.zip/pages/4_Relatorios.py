import streamlit as st

st.title("Página: 4 Relatorios")
st.write("Conteúdo de 4 Relatorios aqui.")